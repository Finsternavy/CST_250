﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PeopleFileIO
{
    public class Person
    {
        public string name { get; set; }
        public string game { get; set; }
        public string url { get; set; }
    }
}
